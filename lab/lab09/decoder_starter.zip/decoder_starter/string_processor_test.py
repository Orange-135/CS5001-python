from string_processor import StringProcessor

def test_process_string():
    """Test for process_string function"""
    sp = StringProcessor()

    assert sp.process_string("ab") == ""
    assert sp.process_string("ab*") == "b"
    assert sp.process_string("ab^") == "ba"
    assert sp.process_string("^") == ""
    assert sp.process_string("b-5es^m9c*u?er^xl0t*a") == "secret"
    assert sp.process_string("na0s*9-o*veXul^z-2it^,no^pr8") == "open the pod bay doors, HAL"
    assert sp.process_string("zeM^un-e*0 t^a*l t^75*4a1:^s35*A,P ^2NM* ,^Mc.+GcO^ t^3*,0^2 ^5m0*x22^") == "the eagle has landed"
